

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="container text-center mt-5">
            <h2 class="headline">
                <span class="support-text"> </span><br>Register with
                <span class="highlight">Abeer Education</span>
            </h2>
            <div class="line"></div>
        </div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-12">
                    <div class="card" style="margin-top: 50px">
                        <div class="card-header">
                            <h2 class="headline">
                                <span class="support-text"> </span><br>Program : <span class="highlight">
                                    <?php echo e($program->name); ?>

                                </span>
                            </h2>
                            <span class="support-text"> </span><br>University :
                            <span class="highlight" style="font-weight:bold">
                                <?php echo e($program->university->name); ?>

                            </span>
                        </div>

                        <div class="card-body">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                            <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php elseif(session('error')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?>

                            <form action="<?php echo e(route('programs.submitApplication')); ?>" method="POST"
                                enctype="multipart/form-data" style="margin: 0px auto;">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" id="universityId" name="university_id"
                                    value="<?php echo e($program->university_id); ?>">
                                <input type="hidden" id="programId" name="program_id" value="<?php echo e($program->id); ?>">
                                <div class="applyform">
                                    <div class="form-group">
                                        <label for="applicantName"> </label>
                                        <input placeholder="Full name" type="text" class="form-control"
                                            id="applicantName" name="name" value="<?php echo e(old('name')); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <input placeholder="Email" type="email" class="form-control" id="applicantEmail"
                                            name="email" value="<?php echo e(old('email')); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <input placeholder="Phone Number" type="tel" class="form-control"
                                            id="applicantPhoneNumber" name="phone_number" value="<?php echo e(old('phone_number')); ?>"
                                            required>
                                    </div>
                                    <div class="form-group">
                                        <label for="applicantAttachment">Last Certificate</label>
                                        <input type="file" class="form-control" id="applicantAttachment"
                                            name="attachment">
                                    </div>
                                    <div class="form-group">
                                        <label for="applicantPassport">Passport</label>
                                        <input type="file" class="form-control" id="applicantPassport" name="passport">
                                    </div>
                                    <button type="submit" class="rts-btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Include CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css" />

    <!-- Include JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var input = document.querySelector("#applicantPhoneNumber");
            var iti = window.intlTelInput(input, {
                initialCountry: "auto",
                geoIpLookup: function(callback) {
                    fetch('https://ipinfo.io/json', {
                            headers: {
                                'Accept': 'application/json'
                            }
                        })
                        .then((resp) => resp.json())
                        .then((resp) => {
                            callback(resp.country);
                        })
                        .catch(() => {
                            callback("us");
                        });
                },
                utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js"
            });

            function updatePhoneNumber() {
                var fullNumber = iti.getNumber();
                input.value = fullNumber;
            }

            input.addEventListener("countrychange", updatePhoneNumber);
            input.addEventListener("blur", updatePhoneNumber);

            updatePhoneNumber();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\abeer\resources\views/pages/apply_form.blade.php ENDPATH**/ ?>