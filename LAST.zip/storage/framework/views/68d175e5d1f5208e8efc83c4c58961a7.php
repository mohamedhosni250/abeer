    <!-- header style one -->
    
    <header class="header-one v-2 ">
        <div class="header-top-one-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div style="padding: 10px;" class="header-top-one">
                            <div class="left-information">
                                <a href="mailto:info@abeereducation.com" class="email"><i
                                        class="fa-light fa-envelope"></i>info@abeereducation.com</a>
                                <a href="tel:+201025492088" class="email"><i
                                        class="fa-light fa-phone"></i>+201025492088</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="header-one-wrapper">
                        <div class="left-side-header">
                            <a href="/" class="logo-area">
                                <img width="180px" src="<?php echo e(asset('logo.png')); ?>" alt="logo">
                            </a>

                            <div class="main-nav-one">
                                <nav>
                                    <ul>
                                        <li style="position: static;">
                                            <a class="nav-link <?php echo e(isActive('/')); ?>" href="<?php echo e(url('/')); ?>">Home</a>
                                        </li>
                                        <li style="position: static;">
                                            <a class="nav-link <?php echo e(isActive('universities*')); ?>"
                                                href="<?php echo e(route('universities.index')); ?>">Universities In Malaysia</a>
                                        </li>
                                        <li style="position: static;">
                                            <a class="nav-link <?php echo e(isActive('courses*')); ?>"
                                                href="<?php echo e(route('courses')); ?>">
                                                Courses</a>
                                        </li>
                                        <li style="position: static;">
                                            <a class="nav-link <?php echo e(isActive('about*')); ?>"
                                                href="<?php echo e(route('about')); ?>">About Us</a>
                                        </li>
                                        <li style="position: static;">
                                            <a class="nav-link <?php echo e(isActive('contact*')); ?>"
                                                href="<?php echo e(route('contact')); ?>">Contact us</a>
                                        </li>
                                        <li style="position: static;">
                                            <a class="nav-link <?php echo e(isActive('leads*')); ?>"
                                                href="<?php echo e(route('leads')); ?>">Registration
                                            </a>
                                        </li>
                                        <li style="position: static;">
                                            <a class="nav-link <?php echo e(isActive('blog*')); ?>"
                                                href="<?php echo e(route('posts')); ?>">Blog
                                            </a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="header-right-area-one">

                            <div class="buttons-area">
                                <?php if(auth()->guard()->check()): ?>
                                    <a href="<?php echo e(route('dashboard')); ?>" class="rts-btn btn-border">Dashboard</a>
                                    <a href="<?php echo e(route('logout')); ?>" class="rts-btn btn-primary"
                                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                        Logout
                                    </a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                        style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                <?php else: ?>
                                    <a href="<?php echo e(route('login')); ?>" class="rts-btn btn-border">Log In</a>
                                    <a href="<?php echo e(route('register')); ?>" class="rts-btn btn-primary">Sign Up</a>
                                <?php endif; ?>
                            </div>
                            <div class="menu-btn" id="menu-btn">
                                <svg width="20" height="16" viewBox="0 0 20 16" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <rect y="14" width="20" height="2" fill="#1F1F25"></rect>
                                    <rect y="7" width="20" height="2" fill="#1F1F25"></rect>
                                    <rect width="20" height="2" fill="#1F1F25"></rect>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
<?php /**PATH C:\laragon\www\abeer\resources\views/partials/header.blade.php ENDPATH**/ ?>