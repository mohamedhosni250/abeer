

<?php $__env->startSection('content'); ?>
    <div class="rts-lession-details-area-start">
        <div class="rts-lession-content-wrapper">
            <div class="rts-lession-left">

                <!-- course content accordion area -->
                <div class="course-content-wrapper-main">
                    <div class="accordion mt--30" id="accordionExample">
                        <?php $__currentLoopData = $course->videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading<?php echo e($index); ?>">
                                    <button class="accordion-button <?php if($index != 0): ?> collapsed <?php endif; ?>"
                                        type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse<?php echo e($index); ?>"
                                        aria-expanded="<?php echo e($index == 0 ? 'true' : 'false'); ?>"
                                        aria-controls="collapse<?php echo e($index); ?>">
                                        <span><?php echo e($video->title); ?></span>
                                    </button>
                                </h2>
                                <div id="collapse<?php echo e($index); ?>"
                                    class="accordion-collapse collapse <?php echo e($index == 0 ? 'show' : ''); ?>"
                                    aria-labelledby="heading<?php echo e($index); ?>" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <a href="<?php echo e(route('course.show', ['slug' => $course->slug, 'video_id' => $video->id])); ?>"
                                            class="play-vedio-wrapper">
                                            <div class="left">
                                                <i class="fa-light fa-circle-play"></i>
                                                <span><?php echo e($video->title); ?></span>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="rts-lession-right">
                <div class="lesson-top-bar">
                    <div class="left-area">
                        <div class="toggle-class" id="toggle-left-back">
                            <i class="fa-light fa-chevron-left"></i>
                        </div>
                        <span>Course Content</span>
                    </div>
                    <div class="right">
                        <a href="course-two.html"><i class="fa-solid fa-x"></i></a>
                    </div>
                </div>

                <iframe id="mainVideo" width="100%" height="315" src="<?php echo e($course->videos->first()->link); ?>"
                    title="<?php echo e($course->videos->first()->title); ?>" frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen></iframe>
                <div class="lesson-bottom-area">
                    <h5 class="title mb--10">About Lesson</h5>
                    <p class="disc">
                        <?php echo e($course->description); ?>

                    </p>
                </div>
                <div class="next-prev-area">
                    <div class="prev">
                        <i class="fa-sharp fa-solid fa-play"></i>
                        Prev
                    </div>
                    <div class="next">
                        Prev
                        <i class="fa-sharp fa-solid fa-play"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\abeer\resources\views/pages/course_single_page.blade.php ENDPATH**/ ?>