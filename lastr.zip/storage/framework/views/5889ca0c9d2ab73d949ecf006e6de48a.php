<img width="150px" src="abeer-white.png" alt="">
<?php /**PATH C:\laragon\www\abeer\resources\views/components/application-logo.blade.php ENDPATH**/ ?>