<!DOCTYPE html>
<html>

<head>
    <title>Application Submitted</title>
</head>

<body>
    <h1>New Application Submitted</h1>
    <p><strong>Name:</strong> <?php echo e($data['name']); ?></p>
    <p><strong>Email:</strong> <?php echo e($data['email']); ?></p>
    <p><strong>Phone Number:</strong> <?php echo e($data['phone_number']); ?></p>
    <p><strong>Certificate:</strong> <a href="<?php echo e($data['attachment']); ?>">View</a></p>
    <p><strong>Passport:</strong> <a href="<?php echo e($data['passport']); ?>">View</a></p>

</body>

</html>
<?php /**PATH C:\laragon\www\abeer\resources\views/emails/application.blade.php ENDPATH**/ ?>