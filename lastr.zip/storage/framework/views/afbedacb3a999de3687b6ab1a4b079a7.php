<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Abeer Education </title>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('fav.jpg')); ?>">
    <!-- fontawesome 6.4.2 -->
    <link rel="stylesheet" href="<?php echo e(asset('css/plugins/fontawesome-6.css')); ?>">
    <!-- swiper Css 10.2.0 -->
    <link rel="stylesheet" href="<?php echo e(asset('css/plugins/swiper.min.css')); ?>">
    <!-- magnific popup css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/vendor/magnific-popup.css')); ?>">
    <!-- Bootstrap 5.0.2 -->
    <link rel="stylesheet" href="<?php echo e(asset('css/vendor/bootstrap.min.css')); ?>">
    <!-- jquery ui css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/vendor/jquery-ui.css')); ?>">
    <!-- metismenu scss -->
    <link rel="stylesheet" href="<?php echo e(asset('css/vendor/metismenu.css')); ?>">
    <!-- custom style css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">

</head>

<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Ensure jQuery is loaded first -->
<script src="<?php echo e(asset('js/vendor/jquery.min.js')); ?>"></script>
<!-- jQuery UI -->
<script src="<?php echo e(asset('js/vendor/jquery-ui.js')); ?>"></script>
<!-- Other scripts -->
<script src="<?php echo e(asset('js/vendor/metismenu.js')); ?>"></script>
<script src="<?php echo e(asset('js/vendor/magnifying-popup.js')); ?>"></script>
<script src="<?php echo e(asset('js/plugins/swiper.js')); ?>"></script>
<script src="<?php echo e(asset('js/plugins/counterup.js')); ?>"></script>
<script src="<?php echo e(asset('js/vendor/waypoint.js')); ?>"></script>
<script src="<?php echo e(asset('js/vendor/waw.js')); ?>"></script>
<script src="<?php echo e(asset('js/plugins/isotop.js')); ?>"></script>
<script src="<?php echo e(asset('js/plugins/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/plugins/resizer-sensor.js')); ?>"></script>
<script src="<?php echo e(asset('js/plugins/sticky-sidebar.js')); ?>"></script>
<script src="<?php echo e(asset('js/plugins/twinmax.js')); ?>"></script>
<script src="<?php echo e(asset('js/vendor/chroma.min.js')); ?>"></script>
<!-- Bootstrap 5.0.2 -->
<script src="<?php echo e(asset('js/plugins/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/plugins/contact.form.js')); ?>"></script>
<script src="<?php echo e(asset('js/plugins/calender.js')); ?>"></script>
<!-- Main JS -->
<script src="<?php echo e(asset('js/main.js')); ?>"></script>

<!-- Your custom script -->


<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


<style>
    /* Your custom styles here */
</style>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\abeer\resources\views/layouts/main.blade.php ENDPATH**/ ?>