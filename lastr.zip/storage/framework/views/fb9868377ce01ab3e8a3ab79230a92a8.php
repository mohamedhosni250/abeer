

<?php $__env->startSection('content'); ?>
    <div class="single-university-page">
        <div class="coursearea">
            <div class="container">
                <div class="row">

                    <div class="col-lg-8">
                        <div class="university-card">
                            <div class="thumbnail">
                                <img src="<?php echo e(asset($university->featured_image_url)); ?>" alt="University Image"
                                    class="img-fluid">
                            </div>
                            <div class="university-content text-center">
                                <div class="university-logo mb-3">
                                    <img src="<?php echo e(asset($university->logo_url)); ?>" alt="University Logo" class="logo-img">
                                </div>
                                <h3 style="padding-top: 3%" class="university-title"><?php echo e($university->name); ?></h3>
                                <p class="university-location">
                                    <i class="fa fa-map-marker-alt"></i> <?php echo e($university->location->name); ?>

                                </p>
                            </div>
                        </div>

                    </div>
                    <div class="col-lg-4 mb-4">
                        <div style="padding: 8%" class="university-stats-card">
                            <div class="stats">
                                <div class="stat-item">
                                    <i class="fa fa-star"></i>
                                    <span>Top</span>
                                    <p>Ranking</p>
                                </div>
                                <div class="stat-item">
                                    <i class="fa fa-graduation-cap"></i>
                                    <span>+<?php echo e($university->students_count); ?></span>
                                    <p>Students</p>
                                </div>
                                <div class="stat-item">
                                    <i class="fa fa-book"></i>
                                    <span><?php echo e($university->programs_count); ?></span>
                                    <p>Programs</p>
                                </div>
                            </div>
                            <div class="separator">
                                <hr />
                                <i class="fa fa-info-circle"></i>
                                <hr />
                            </div>
                            <p><?php echo $university->description; ?></p>
                            <p style="font-weight:bold" class="starting-fee">Starting From
                                <span><?php echo e($university->starting_fee); ?>$</span>
                            </p>
                            <a style="margin: 51px auto;" href="#myTab" class="rts-btn btn-primary">Apply Now </a>


                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            
            <div class="container p-4">
                <div class="container text-center mt-5 mb-10 hosni-headline">
                    <h2 class="headline">
                        <span class="support-text"> </span><br> Details About <span
                            class="highlight"><?php echo e($university->name); ?></span>
                    </h2>
                    <div style="margin-bottom:50px" class="line"></div>
                </div>
                <div class="accordion accordion-flush" id="accordionFlushExample">

                    <?php $__currentLoopData = $university->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="accordion-item rounded-3 border-0 shadow mb-2">
                            <h2 class="accordion-header">
                                <button
                                    class="accordion-button border-bottom <?php echo e($index === 0 ? '' : 'collapsed'); ?> fw-semibold"
                                    type="button" data-bs-toggle="collapse"
                                    data-bs-target="#flush-collapse<?php echo e($index); ?>"
                                    aria-expanded="<?php echo e($index === 0 ? 'true' : 'false'); ?>"
                                    aria-controls="flush-collapse<?php echo e($index); ?>">
                                    <?php echo e($detail->tab_name); ?>

                                </button>
                            </h2>
                            <div id="flush-collapse<?php echo e($index); ?>"
                                class="accordion-collapse collapse <?php echo e($index === 0 ? 'show' : ''); ?>"
                                data-bs-parent="#accordionFlushExample">
                                <div class="accordion-body">
                                    <?php echo $detail->content; ?>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>

            
            <div id="" class="course-details-btn-wrapper full-width pb--50">
                <div class="course__text">
                    <p>Showing <?php echo e($university->programs->count()); ?> Results</p>
                </div>
                <ul class="nav nav-tabs" id="myTab" role="tablist">


                    <?php $__currentLoopData = $degrees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $degreeId => $programs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link <?php if($loop->first): ?> active <?php endif; ?>" id="home-tab"
                                data-bs-toggle="tab" data-bs-target="#degree_<?php echo e($degreeId); ?>" type="button"
                                role="tab" aria-controls="home" aria-selected="true">
                                <?php echo e($programs->first()->degree->name); ?>

                            </button>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </div>
            <div class="tab-content mt--50" id="myTabContent">
                <div class="tab-pane fade  show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                    <div class="tab-content tab__content__wrapper" id="myTabContent">
                        <?php $__currentLoopData = $degrees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $degreeId => $programs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-pane fade <?php if($loop->first): ?> show active <?php endif; ?>"
                                id="degree_<?php echo e($degreeId); ?>" role="tabpanel">
                                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('programs', ['degreeName' => $degreeId,'universityId' => $university->id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-1203323731-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                    <div class="course-content-wrapper-main">
                        <h5 class="title">Course Content</h5>
                    </div>

                </div>
            </div>

        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\abeer\resources\views/pages/university_single_page.blade.php ENDPATH**/ ?>