

<?php $__env->startSection('content'); ?>
    <div class="rts-section-gap rts-blog-area">
        <div class="container pb--130">
            <div class="row g-5 mt--20">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4">
                        <div class="single-blog-style-one">
                            <a href="<?php echo e(route('post.show', $post->slug)); ?>" class="thumbnail">
                                <img src="<?php echo e(asset($post->thumbnail_url)); ?>" alt="<?php echo e($post->title); ?>">
                            </a>
                            <div class="blog-top-area">

                                <div class="tags-area">

                                </div>
                                <div class="single">
                                    <i class="fa-light fa-calendar-days"></i>
                                    <p><?php echo e($post->created_at->format('F d, Y')); ?></p>
                                </div>
                            </div>

                            <a href="<?php echo e(route('post.show', $post->slug)); ?>">
                                <h5 class="title"><?php echo e($post->title); ?></h5>
                            </a>

                            <a href="<?php echo e(route('post.show', $post->slug)); ?>" class="rts-btn btn-primary">
                                Read More
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="rts-elevate-pagination">
                        <?php echo e($posts->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\abeer\resources\views/pages/blog.blade.php ENDPATH**/ ?>